import react from '@vitejs/plugin-react'
import { Buffer } from 'node:buffer'
import { defineConfig } from 'vite'
import { randomBytes, randomUUID, scrypt as scryptCallback } from 'node:crypto'
import { dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { mkdir, readFile, rename, writeFile } from 'node:fs/promises'

const signupsFile = fileURLToPath(new URL('./data/signups.json', import.meta.url))
let signupWrites = Promise.resolve()

function signupApi() {
  return {
    name: 'signup-api',
    configureServer(server) {
      server.middlewares.use(async (request, response, next) => {
        if (new URL(request.url || '/', 'http://localhost').pathname !== '/api/signup') {
          next()
          return
        }

        const sendJson = (status, payload) => {
          response.statusCode = status
          response.setHeader('Content-Type', 'application/json')
          response.end(JSON.stringify(payload))
        }

        if (request.method !== 'POST') {
          sendJson(405, { error: 'Use POST to submit the signup form.' })
          return
        }

        try {
          const chunks = []
          let bodySize = 0

          for await (const chunk of request) {
            bodySize += chunk.byteLength
            if (bodySize > 16 * 1024) {
              sendJson(413, { error: 'Signup request is too large.' })
              return
            }
            chunks.push(chunk)
          }

          let submitted
          try {
            submitted = JSON.parse(Buffer.concat(chunks).toString('utf8'))
          } catch {
            sendJson(400, { error: 'Signup request must contain valid JSON.' })
            return
          }

          if (!submitted || typeof submitted !== 'object' || Array.isArray(submitted)) {
            sendJson(400, { error: 'Signup request must contain a JSON object.' })
            return
          }

          const name = typeof submitted.name === 'string' ? submitted.name.trim() : ''
          const email = typeof submitted.email === 'string' ? submitted.email.trim().toLowerCase() : ''
          const password = typeof submitted.password === 'string' ? submitted.password : ''

          if (!name || name.length > 100 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || password.length < 8 || password.length > 128) {
            sendJson(400, { error: 'Enter a name, valid email address, and password between 8 and 128 characters.' })
            return
          }

          const salt = randomBytes(16).toString('hex')
          const passwordHash = await new Promise((resolve, reject) => {
            scryptCallback(password, salt, 64, (error, derivedKey) => {
              if (error) reject(error)
              else resolve(derivedKey.toString('hex'))
            })
          })

          const signup = {
            id: randomUUID(),
            name,
            email,
            passwordSalt: salt,
            passwordHash,
            createdAt: new Date().toISOString(),
          }
          const saveSignup = signupWrites.then(async () => {
            let signups = []
            try {
              signups = JSON.parse(await readFile(signupsFile, 'utf8'))
            } catch (error) {
              if (error.code !== 'ENOENT') throw error
            }

            if (!Array.isArray(signups)) {
              throw new Error('Signup data file must contain a JSON array.')
            }
            if (signups.some((existing) => existing.email === email)) {
              const error = new Error('An account with this email already exists.')
              error.statusCode = 409
              throw error
            }

            await mkdir(dirname(signupsFile), { recursive: true })
            const temporaryFile = `${signupsFile}.${randomUUID()}.tmp`
            await writeFile(temporaryFile, `${JSON.stringify([...signups, signup], null, 2)}\n`, 'utf8')
            await rename(temporaryFile, signupsFile)
          })
          signupWrites = saveSignup.catch(() => {})
          await saveSignup

          sendJson(201, { message: 'Signup saved.' })
        } catch (error) {
          if (error.statusCode === 409) {
            sendJson(409, { error: error.message })
            return
          }
          sendJson(500, { error: 'Unable to save your signup. Please try again.' })
        }
      })
    },
  }
}

// https://vite.dev/config/
export default defineConfig({
  plugins: [react(), signupApi()],
})
