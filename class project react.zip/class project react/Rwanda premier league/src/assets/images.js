import stadiumImage from './football.jpg';
import leagueLogo from './logo.png';

export { stadiumImage, leagueLogo };