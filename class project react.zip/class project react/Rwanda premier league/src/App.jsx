import { useMemo, useState } from 'react';
import { leagueLogo } from './assets/images.js';

const heroActionImage = 'https://images.unsplash.com/photo-1518604666860-9ed391f76460?auto=format&fit=crop&w=1800&q=80';

const navItems = [
  { key: 'home', label: 'Home' },
  { key: 'fixtures', label: 'Fixtures' },
  { key: 'teams', label: 'Teams' },
  { key: 'leagueTable', label: 'League Table' },
  { key: 'dashboard', label: 'Dashboard' },
  { key: 'addFixture', label: 'Add Fixture' },
];

const matches = [
  { home: 'APR FC', away: 'Gasogi United', venue: 'Amahoro Stadium', date: 'Aug 20', time: '15:00 CAT' },
  { home: 'Rayon Sports', away: 'Police FC', venue: 'Kigali Pele Stadium', date: 'Aug 21', time: '15:00 CAT' },
  { home: 'AS Kigali', away: 'Musanze FC', venue: 'Mumena Stadium', date: 'Aug 14', time: '15:00 CAT', result: '2 - 1' },
  { home: 'Mukura VS', away: 'Etincelles FC', venue: 'Nyagatare Stadium', date: 'Aug 24', time: '17:00 CAT' },
];

const initialTeams = [
  { name: 'APR FC', location: 'Kigali', stadium: 'Amahoro Stadium', position: '1st', wins: '15', points: '49', short: 'APR' },
  { name: 'Rayon Sports', location: 'Kigali', stadium: 'Kigali Pele Stadium', position: '2nd', wins: '14', points: '45', short: 'RSP' },
  { name: 'Police FC', location: 'Kigali', stadium: 'Kigali Pele Stadium', position: '3rd', wins: '12', points: '41', short: 'PFC' },
  { name: 'AS Kigali', location: 'Kigali', stadium: 'Mumena Stadium', position: '4th', wins: '11', points: '39', short: 'ASK' },
  { name: 'Musanze FC', location: 'Northern Province', stadium: 'Musanze Arena', position: '5th', wins: '10', points: '35', short: 'MSZ' },
  { name: 'Etincelles FC', location: 'Eastern Province', stadium: 'Gisenyi Stadium', position: '6th', wins: '9', points: '31', short: 'ETC' },
];

const fixturesSeed = [
  { id: 'fixture-1', date: 'AUGUST 20, 2026', time: '15:00 CAT', home: 'APR FC', away: 'Gasogi United', venue: 'Amahoro Stadium', status: 'upcoming' },
  { id: 'fixture-2', date: 'AUGUST 21, 2026', time: '15:00 CAT', home: 'Rayon Sports', away: 'Police FC', venue: 'Kigali Pele Stadium', status: 'upcoming' },
  { id: 'fixture-3', date: 'August 14, 2026', time: '15:00 CAT', home: 'AS Kigali', away: 'Musanze FC', venue: 'Mumena Stadium', status: 'completed', result: '2 - 1' },
  { id: 'fixture-4', date: 'August 10, 2026', time: '17:00 CAT', home: 'Mukura VS', away: 'Etincelles FC', venue: 'Nyagatare Stadium', status: 'completed', result: '1 - 1' },
];

function calculateStandings(teams, fixtures) {
  const rows = new Map();
  const getRow = (name) => {
    if (!rows.has(name)) {
      rows.set(name, { club: name, played: 0, won: 0, drawn: 0, lost: 0, goalsFor: 0, goalsAgainst: 0, points: 0 });
    }
    return rows.get(name);
  };

  teams.forEach((team) => getRow(team.name));

  fixtures.forEach((fixture) => {
    if (fixture.status !== 'completed') return;

    const scores = fixture.result?.match(/^\s*(\d+)\s*-\s*(\d+)\s*$/);
    if (!scores) return;

    const homeScore = Number(scores[1]);
    const awayScore = Number(scores[2]);
    const home = getRow(fixture.home);
    const away = getRow(fixture.away);

    home.played += 1;
    away.played += 1;
    home.goalsFor += homeScore;
    home.goalsAgainst += awayScore;
    away.goalsFor += awayScore;
    away.goalsAgainst += homeScore;

    if (homeScore > awayScore) {
      home.won += 1;
      home.points += 3;
      away.lost += 1;
    } else if (awayScore > homeScore) {
      away.won += 1;
      away.points += 3;
      home.lost += 1;
    } else {
      home.drawn += 1;
      away.drawn += 1;
      home.points += 1;
      away.points += 1;
    }
  });

  return [...rows.values()]
    .map((row) => ({ ...row, goalDifference: row.goalsFor - row.goalsAgainst }))
    .sort((a, b) => b.points - a.points || b.goalDifference - a.goalDifference || b.goalsFor - a.goalsFor || a.club.localeCompare(b.club))
    .map((row, index) => ({ ...row, position: index + 1 }));
}

function App() {
  const [page, setPage] = useState('home');
  const [authMode, setAuthMode] = useState('login');
  const [teamFilter, setTeamFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [showResultModal, setShowResultModal] = useState(false);
  const [fixtures, setFixtures] = useState(fixturesSeed);
  const [teams, setTeams] = useState(initialTeams);
  const [selectedFixtureId, setSelectedFixtureId] = useState(fixturesSeed[0].id);
  const [fixtureFilter, setFixtureFilter] = useState('all');
  const [signupMessage, setSignupMessage] = useState('');
  const [signupError, setSignupError] = useState('');

  const handleAdminLogin = (event) => {
    event.preventDefault();

    const formData = new FormData(event.currentTarget);
    const email = (formData.get('email') || '').toString().trim().toLowerCase();
    const password = (formData.get('password') || '').toString().trim();

    const isAdmin = email.includes('admin') || email === 'admin@rwanda-premier-league.com';

    if (!isAdmin || !password) {
      alert('Use admin credentials to access the dashboard.');
      return;
    }

    setPage('dashboard');
    setAuthMode('login');
  };

  const handleSignup = async (event) => {
    event.preventDefault();
    setSignupMessage('');
    setSignupError('');

    const form = event.currentTarget;
    const formData = new FormData(event.currentTarget);
    const signup = {
      name: formData.get('name')?.toString().trim(),
      email: formData.get('email')?.toString().trim(),
      password: formData.get('password')?.toString(),
    };

    try {
      const response = await fetch('/api/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(signup),
      });
      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || 'Unable to create your account.');
      }

      form.reset();
      setSignupMessage('Your signup has been saved.');
    } catch (error) {
      setSignupError(error instanceof Error ? error.message : 'Unable to create your account.');
    }
  };

  const handleRemind = () => {
    setPage('auth');
    setAuthMode('signup');
    setSignupMessage('');
    setSignupError('');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const standings = useMemo(() => calculateStandings(teams, fixtures), [teams, fixtures]);

  const filteredTeams = useMemo(() => {
    return teams.filter((team) => {
      const matchesLocation = teamFilter === 'all' || team.location.toLowerCase().includes(teamFilter.toLowerCase());
      const matchesSearch = team.name.toLowerCase().includes(search.toLowerCase());
      return matchesLocation && matchesSearch;
    }).map((team) => {
      const standing = standings.find((row) => row.club === team.name);
      return {
        ...team,
        position: standing ? `${standing.position}${standing.position === 1 ? 'st' : standing.position === 2 ? 'nd' : standing.position === 3 ? 'rd' : 'th'}` : '-',
        wins: String(standing?.won ?? 0),
        points: String(standing?.points ?? 0),
      };
    });
  }, [teamFilter, search, teams, standings]);

  const handleDeleteTeam = (teamName) => {
    const confirmed = window.confirm(`Are you sure you want to delete ${teamName}?`);

    if (!confirmed) {
      return;
    }

    setTeams((current) => current.filter((team) => team.name !== teamName));
  };

  const handleSaveResult = (event) => {
    event.preventDefault();

    const formData = new FormData(event.currentTarget);
    const fixtureId = formData.get('fixtureId')?.toString();
    const homeScore = formData.get('homeScore')?.toString().trim();
    const awayScore = formData.get('awayScore')?.toString().trim();

    if (!fixtureId || homeScore === '' || awayScore === '') return;

    setFixtures((current) => current.map((fixture) => (
      fixture.id === fixtureId
        ? { ...fixture, status: 'completed', result: `${homeScore} - ${awayScore}` }
        : fixture
    )));
    setShowResultModal(false);
  };

  const handleAddTeam = (event) => {
    event.preventDefault();

    const formData = new FormData(event.currentTarget);
    const name = formData.get('teamName')?.toString().trim();
    const location = formData.get('teamLocation')?.toString().trim();
    const stadium = formData.get('teamStadium')?.toString().trim();

    if (!name || !location || !stadium) {
      return;
    }

    const short = name
      .split(' ')
      .map((part) => part[0])
      .join('')
      .slice(0, 3)
      .toUpperCase();

    setTeams((current) => [
      ...current,
      {
        name,
        location,
        stadium,
        position: `${current.length + 1}th`,
        wins: '0',
        points: '0',
        short,
      },
    ]);

    setPage('teams');
    setSearch('');
    setTeamFilter('all');
    event.currentTarget.reset();
  };

  const handleAddFixture = (event) => {
    event.preventDefault();

    const formData = new FormData(event.currentTarget);
    const homeTeam = formData.get('homeTeam')?.toString().trim() || 'Home Team';
    const awayTeam = formData.get('awayTeam')?.toString().trim() || 'Away Team';
    const matchDate = formData.get('matchDate')?.toString();
    const matchTime = formData.get('matchTime')?.toString();
    const venue = formData.get('venue')?.toString().trim() || 'Main Stadium';

    if (!matchDate || !matchTime) {
      return;
    }

    const date = new Date(`${matchDate}T12:00:00`);
    const formattedDate = new Intl.DateTimeFormat('en-US', {
      month: 'long',
      day: 'numeric',
      year: 'numeric',
    }).format(date);

    setFixtures((current) => [
      {
        id: `fixture-${Date.now()}`,
        date: formattedDate,
        time: `${matchTime} CAT`,
        home: homeTeam,
        away: awayTeam,
        venue,
        status: 'upcoming',
      },
      ...current,
    ]);

    setFixtureFilter('upcoming');
    setPage('fixtures');
  };

  const renderPage = () => {
    switch (page) {
      case 'fixtures':
        return <FixturesPage fixtures={fixtures} filter={fixtureFilter} setFilter={setFixtureFilter} onRemind={handleRemind} />;
      case 'teams':
        return (
          <TeamsPage
            teamFilter={teamFilter}
            setTeamFilter={setTeamFilter}
            search={search}
            setSearch={setSearch}
            filteredTeams={filteredTeams}
            onDeleteTeam={handleDeleteTeam}
            onAddTeam={handleAddTeam}
          />
        );
      case 'leagueTable':
        return <LeagueTablePage standings={standings} />;
      case 'dashboard':
        return (
          <DashboardPage
            fixtures={fixtures}
            standings={standings}
            showResultModal={showResultModal}
            selectedFixtureId={selectedFixtureId}
            onOpenResult={(fixtureId) => {
              setSelectedFixtureId(fixtureId || fixtures.find((fixture) => fixture.status === 'upcoming')?.id || fixtures[0]?.id || '');
              setShowResultModal(true);
            }}
             onSelectFixture={setSelectedFixtureId}
            onCloseResult={() => setShowResultModal(false)}
            onSaveResult={handleSaveResult}
          />
        );
      case 'addFixture':
        return <AddFixturePage onAddFixture={handleAddFixture} />;
      case 'auth':
        return (
          <AuthPage
            authMode={authMode}
            setAuthMode={setAuthMode}
            onAdminLogin={handleAdminLogin}
            onSignup={handleSignup}
            signupMessage={signupMessage}
            signupError={signupError}
          />
        );
      default:
        return <HomePage />;
    }
  };

  return (
    <div className="app-shell">
      <header className="site-header">
        <div className="container header-container">
          <div className="logo-wrap">
            <img src={leagueLogo} alt="Rwanda Premier League logo" className="league-logo" />
            <h1>Rwanda Premier League</h1>
          </div>

          <nav className="nav-menu">
            {navItems.map((item) => (
              <button
                key={item.key}
                type="button"
                className={`nav-link ${page === item.key ? 'active' : ''}`}
                onClick={() => setPage(item.key)}
              >
                {item.label}
              </button>
            ))}
            <button type="button" className="nav-link login-button" onClick={() => {
              setPage('auth');
              setAuthMode('login');
            }}>
              Login
            </button>
          </nav>
        </div>
      </header>

      {renderPage()}
    </div>
  );
}

function HomePage() {
  return (
    <>
      <section className="hero-section" style={{ backgroundImage: `linear-gradient(rgba(8, 10, 14, 0.28), rgba(10, 12, 18, 0.74)), url(${heroActionImage})` }}>
        <div className="container hero-content-wrap">
          <div className="hero-content">
            <span className="hero-kicker">Rwanda Premier League</span>
            <h2>Bring the stadium energy home.</h2>
            <p>
              Live fixtures, club battles, and matchday drama from Rwanda’s most exciting football competition.
            </p>
            <div className="hero-buttons">
              <button type="button" className="primary-btn">Watch Fixtures</button>
              <button type="button" className="secondary-btn">Explore Clubs</button>
            </div>
            <div className="hero-stats">
              <div>
                <strong>18</strong>
                <span>clubs</span>
              </div>
              <div>
                <strong>12.6K</strong>
                <span>crowd</span>
              </div>
              <div>
                <strong>21</strong>
                <span>rounds</span>
              </div>
            </div>
          </div>

          <div className="hero-panel" aria-label="Live match card">
            <div className="hero-panel-top">
              <span>Matchday 21</span>
              <span className="live-pill">Live</span>
            </div>

            <div className="score-box-row">
              <div className="team-score">
                <span className="team-badge apr">APR</span>
                <strong>APR FC</strong>
              </div>
              <div className="score-numbers">2 - 1</div>
              <div className="team-score away">
                <span className="team-badge gas">GAS</span>
                <strong>Gasogi</strong>
              </div>
            </div>

            <div className="panel-meta">
              <span>Amahoro Stadium</span>
              <span>15:00 CAT</span>
            </div>
          </div>
        </div>
      </section>

      <section className="section featured-matches">
        <div className="container">
          <h2>Featured Matches</h2>
          <div className="matches-grid">
            {matches.map((match, index) => (
              <div key={index} className="match-card">
                <div className="teams-line">
                  <div className="team-pill">{match.home}</div>
                  <span className="vs-tag">VS</span>
                  <div className="team-pill">{match.away}</div>
                </div>
                <div className="match-meta">
                  <span>{match.date}</span>
                  <span>{match.time}</span>
                </div>
                <p className="venue">{match.venue}</p>
                {match.result ? <div className="score-box">{match.result}</div> : null}
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

function FixturesPage({ fixtures, filter, setFilter, onRemind }) {
  const visibleFixtures = fixtures.filter((fixture) => {
    if (filter === 'all') return true;
    return fixture.status === filter;
  });

  return (
    <section className="section fixtures-section">
      <div className="container">
        <div className="page-intro">
          <p>Stay updated with all the upcoming matches and results from the Rwanda Premier League.</p>
        </div>

        <div className="fixtures-toolbar">
          <div className="filter-group">
            <button type="button" className={`filter-btn ${filter === 'all' ? 'active' : ''}`} onClick={() => setFilter('all')}>All Matches</button>
            <button type="button" className={`filter-btn ${filter === 'upcoming' ? 'active' : ''}`} onClick={() => setFilter('upcoming')}>Upcoming</button>
            <button type="button" className={`filter-btn ${filter === 'completed' ? 'active' : ''}`} onClick={() => setFilter('completed')}>Completed</button>
          </div>
          <select className="select-box" defaultValue="all">
            <option value="all">All Matchdays</option>
            <option value="1">Matchday 1</option>
            <option value="2">Matchday 2</option>
            <option value="3">Matchday 3</option>
          </select>
        </div>

        <div className="fixtures-list">
          <div className="matchday-header">Matchday 21 - August 20-22, 2026</div>

          {visibleFixtures.map((fixture, index) => (
            <div key={`${fixture.home}-${fixture.away}-${index}`} className={`match-fixture ${fixture.status}`}>
              <div className="fixture-date">
                <p>{fixture.date}</p>
                <p>{fixture.time}</p>
              </div>

              <div className="fixture-teams">
                <div className="team-block">
                  <div className="mini-badge">{fixture.home.slice(0, 3).toUpperCase()}</div>
                  <span>{fixture.home}</span>
                </div>
                <div className="vs-block">{fixture.result ? <span className="score-result">{fixture.result}</span> : 'VS'}</div>
                <div className="team-block">
                  <div className="mini-badge">{fixture.away.slice(0, 3).toUpperCase()}</div>
                  <span>{fixture.away}</span>
                </div>
              </div>

              <div className="fixture-venue">
                <p><i className="fas fa-map-marker-alt"></i> {fixture.venue}</p>
              </div>

              <div className="fixture-actions">
                {fixture.status === 'upcoming' ? (
                  <>
                    <button type="button" className="action-btn remind" onClick={onRemind}>Remind</button>
                    <button type="button" className="action-btn ticket">Tickets</button>
                  </>
                ) : (
                  <button type="button" className="action-btn highlight">Highlights</button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function TeamsPage({ teamFilter, setTeamFilter, search, setSearch, filteredTeams, onDeleteTeam, onAddTeam }) {
  return (
    <section className="section teams-section">
      <div className="container">
        <div className="page-intro">
          <h2>Our Teams</h2>
          <p>Get to know all the teams competing in the Rwanda Premier League.</p>
        </div>

        <div className="teams-filter">
          <input
            type="text"
            className="search-input"
            placeholder="Search teams..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <select className="select-box" value={teamFilter} onChange={(e) => setTeamFilter(e.target.value)}>
            <option value="all">All Locations</option>
            <option value="kigali">Kigali</option>
            <option value="north">Northern Province</option>
            <option value="east">Eastern Province</option>
          </select>
        </div>

        <div className="team-form-card">
          <form className="team-form" onSubmit={onAddTeam}>
            <input type="text" name="teamName" placeholder="Team name" />
            <input type="text" name="teamLocation" placeholder="Location" />
            <input type="text" name="teamStadium" placeholder="Stadium" />
            <button type="submit" className="primary-btn">Add Team</button>
          </form>
        </div>

        <div className="teams-grid">
          {filteredTeams.map((team) => (
            <div key={team.name} className="team-card">
              <div className="team-logo">
                <span>{team.short}</span>
              </div>
              <div className="team-info">
                <h3>{team.name}</h3>
                <p className="team-location"><i className="fas fa-map-marker-alt"></i> {team.location}</p>
                <p className="team-stadium"><i className="fas fa-stadium"></i> {team.stadium}</p>
                <div className="team-stats">
                  <div className="stat-box">
                    <span className="stat-value">{team.position}</span>
                    <span className="stat-label">Position</span>
                  </div>
                  <div className="stat-box">
                    <span className="stat-value">{team.wins}</span>
                    <span className="stat-label">Wins</span>
                  </div>
                  <div className="stat-box">
                    <span className="stat-value">{team.points}</span>
                    <span className="stat-label">Points</span>
                  </div>
                </div>
              </div>
              <div className="team-actions">
                <button type="button" className="inner-btn">View Team</button>
                <button type="button" className="inner-btn follow">Follow</button>
                <button type="button" className="inner-btn delete" onClick={() => onDeleteTeam(team.name)}>Delete</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function AuthPage({ authMode, setAuthMode, onAdminLogin, onSignup, signupMessage, signupError }) {
  return (
    <div className="auth-shell">
      <div className="auth-container">
        <div className="form-toggle">
          <button type="button" className={authMode === 'login' ? 'active' : ''} onClick={() => setAuthMode('login')}>Login</button>
          <button type="button" className={authMode === 'signup' ? 'active' : ''} onClick={() => setAuthMode('signup')}>Sign Up</button>
        </div>

        <div className={`forms-wrapper ${authMode === 'signup' ? 'signup-mode' : ''}`}>
          <form className={`auth-form ${authMode === 'login' ? 'visible' : ''}`} onSubmit={onAdminLogin}>
            <h2>Login</h2>
            <label>Email</label>
            <input type="email" name="email" placeholder="admin@rwanda-premier-league.com" />
            <label>Password</label>
            <input type="password" name="password" placeholder="••••••••" />
            <button type="submit" className="submit-btn">Login</button>
          </form>

          <form className={`auth-form ${authMode === 'signup' ? 'visible' : ''}`} onSubmit={onSignup}>
            <h2>Sign Up</h2>
            <label>Name</label>
            <input type="text" name="name" placeholder="Your name" autoComplete="name" maxLength="100" required />
            <label>Email</label>
            <input type="email" name="email" placeholder="you@example.com" autoComplete="email" required />
            <label>Password</label>
            <input type="password" name="password" placeholder="At least 8 characters" autoComplete="new-password" minLength="8" maxLength="128" required />
            {signupError ? <p className="signup-feedback error" role="alert">{signupError}</p> : null}
            {signupMessage ? <p className="signup-feedback success" role="status">{signupMessage}</p> : null}
            <button type="submit" className="submit-btn">Sign Up</button>
          </form>
        </div>
      </div>
    </div>
  );
}

function LeagueTable({ standings }) {
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            <th>Pos</th>
            <th>Club</th>
            <th>P</th>
            <th>W</th>
            <th>D</th>
            <th>L</th>
            <th>GD</th>
            <th>Pts</th>
          </tr>
        </thead>
        <tbody>
          {standings.map((row) => (
            <tr key={row.club}>
              <td>{row.position}</td>
              <td>{row.club}</td>
              <td>{row.played}</td>
              <td>{row.won}</td>
              <td>{row.drawn}</td>
              <td>{row.lost}</td>
              <td>{row.goalDifference > 0 ? `+${row.goalDifference}` : row.goalDifference}</td>
              <td><strong>{row.points}</strong></td>
            </tr>
          ))}
        </tbody>
      </table>
      {standings.length === 0 ? <p className="empty-table">No teams to show yet.</p> : null}
    </div>
  );
}

function LeagueTablePage({ standings }) {
  return (
    <section className="section league-table-page">
      <div className="container">
        <div className="page-intro">
          <h2>League Table</h2>
          <p>Standings are calculated automatically from completed match results.</p>
        </div>
        <div className="table-card">
          <LeagueTable standings={standings} />
        </div>
      </div>
    </section>
  );
}

function DashboardPage({ fixtures, standings, showResultModal, selectedFixtureId, onOpenResult, onSelectFixture, onCloseResult, onSaveResult }) {
  const selectedFixture = fixtures.find((fixture) => fixture.id === selectedFixtureId);
  const selectedScores = selectedFixture?.result?.match(/^\s*(\d+)\s*-\s*(\d+)\s*$/);

  return (
    <div className="dashboard-shell">
      <aside className="dashboard-sidebar">
        <div className="sidebar-brand">
          <div className="brand-mark">
            <span className="mark-circle"></span>
          </div>
          <span className="brand-label">Admin</span>
        </div>

        <nav className="sidebar-menu">
          <button type="button" className="sidebar-link active">Overview</button>
          <button type="button" className="sidebar-link">Fixtures</button>
          <button type="button" className="sidebar-link">Teams</button>
          <button type="button" className="sidebar-link">Reports</button>
        </nav>
      </aside>

      <main className="dashboard-main">
        <div className="dashboard-panel">
          <div className="top-bar">
            <h2>Dashboard</h2>
            <div className="profile-pill">Admin User</div>
          </div>

          <div className="stats-grid">
            {[
              { label: 'Total Teams', value: standings.length, change: 'in the league' },
              { label: 'Matches Played', value: fixtures.filter((fixture) => fixture.status === 'completed').length, change: 'completed fixtures' },
              { label: 'Tickets Sold', value: '8.4K', change: '+18%' },
              { label: 'Avg Attendance', value: '12.6K', change: '+1.2K' },
            ].map((stat) => (
              <div key={stat.label} className="stats-card">
                <span className="stats-label">{stat.label}</span>
                <strong>{stat.value}</strong>
                <small>{stat.change}</small>
              </div>
            ))}
          </div>

          <div className="table-card dashboard-fixtures">
            <div className="card-header">
              <h3>Fixtures</h3>
              <button type="button" className="red-btn" onClick={() => onOpenResult()} disabled={!fixtures.length}>Add Result</button>
            </div>
            {fixtures.length ? (
              <div className="dashboard-fixture-list">
                {fixtures.map((fixture) => (
                  <div className="dashboard-fixture-row" key={fixture.id}>
                    <div>
                      <strong>{fixture.home} <span>{fixture.result || 'vs'}</span> {fixture.away}</strong>
                      <small>{fixture.date} · {fixture.time} · {fixture.venue}</small>
                    </div>
                    <button type="button" className="action-btn highlight" onClick={() => onOpenResult(fixture.id)}>
                      {fixture.status === 'completed' ? 'Edit Result' : 'Record Result'}
                    </button>
                  </div>
                ))}
              </div>
            ) : <p className="empty-table">No fixtures have been added yet.</p>}
          </div>

          <div className="table-card">
            <div className="card-header">
              <h3>League Table</h3>
              <button type="button" className="red-btn" onClick={() => onOpenResult()} disabled={!fixtures.length}>Add Result</button>
            </div>
            <LeagueTable standings={standings} />
          </div>
        </div>
      </main>

      {showResultModal && (
        <div className="result-modal-backdrop" onClick={onCloseResult}>
          <div className="result-modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Add Match Result</h3>
              <button type="button" className="close-btn" onClick={onCloseResult}>×</button>
            </div>

            <form className="result-form" onSubmit={onSaveResult}>
              <div className="result-form-grid">
                <label className="result-field">
                  <span>Fixture</span>
                  <select
                    name="fixtureId"
                    value={selectedFixture?.id ?? ''}
                    onChange={(event) => onSelectFixture(event.target.value)}
                    required
                  >
                    {fixtures.map((fixture) => (
                      <option key={fixture.id} value={fixture.id}>
                        {fixture.home} vs {fixture.away} — {fixture.date}
                      </option>
                    ))}
                  </select>
                </label>

                <label className="result-field">
                  <span>Home Score</span>
                  <input key={`${selectedFixture?.id}-home`} type="number" name="homeScore" defaultValue={selectedScores?.[1] ?? ''} min="0" required />
                </label>

                <label className="result-field">
                  <span>Away Score</span>
                  <input key={`${selectedFixture?.id}-away`} type="number" name="awayScore" defaultValue={selectedScores?.[2] ?? ''} min="0" required />
                </label>
              </div>

              <div className="result-form-actions">
                <button type="button" className="cancel-btn" onClick={onCloseResult}>Cancel</button>
                <button type="submit" className="submit-result-btn" disabled={!selectedFixture}>Save Result</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

function AddFixturePage({ onAddFixture }) {
  return (
    <div className="form-page-shell">
      <div className="fixture-form-card">
        <h2>Add New Fixture</h2>
        <form className="fixture-form" onSubmit={onAddFixture}>
          <label>Home Team</label>
          <input type="text" name="homeTeam" placeholder="Home Team" defaultValue="APR FC" required />

          <label>Away Team</label>
          <input type="text" name="awayTeam" placeholder="Away Team" defaultValue="Gasogi United" required />

          <label>Match Date</label>
          <input type="date" name="matchDate" defaultValue="2026-08-22" required />

          <label>Match Time</label>
          <input type="time" name="matchTime" defaultValue="15:00" required />

          <label>Venue</label>
          <input type="text" name="venue" placeholder="Venue" defaultValue="Amahoro Stadium" required />

          <button type="submit" className="primary-btn full-width">Add Fixture</button>
        </form>
      </div>
    </div>
  );
}

export default App;
