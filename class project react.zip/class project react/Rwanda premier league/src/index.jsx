function index  () {
    return (
        
        <header>
            
            <h1>Rwanda Premier League</h1>
            <p>Welcome to the Rwanda Premier League!</p>
        </header>
        
    );
}
export default index;  